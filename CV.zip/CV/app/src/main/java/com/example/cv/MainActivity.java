package com.example.cv;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button wyborzdjecia;
    ImageView imageView;
    ActivityResultLauncher<Intent> resultLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button wyslij = findViewById(R.id.button);
        wyborzdjecia = findViewById(R.id.wyborzdjecia);
        imageView = findViewById(R.id.imageView);
        Switch sw = findViewById(R.id.switch1);
        LinearLayout mainLayout = findViewById(R.id.main);

        registerResult();

        wyborzdjecia.setOnClickListener(v -> pickImage());
        wyslij.setOnClickListener(v -> pokazDane());

        sw.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                setLayoutEnabled(false, mainLayout);
                sw.setEnabled(true);
            } else {
                setLayoutEnabled(true, mainLayout);
            }
        });
    }

    private void pickImage() {
        Intent intent = new Intent(MediaStore.ACTION_PICK_IMAGES);
        resultLauncher.launch(intent);
    }

    private void registerResult() {
        resultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    Uri imageUri = result.getData().getData();
                    imageView.setImageURI(imageUri);
                });
    }

    private void pokazDane() {

        EditText imieinaz = findViewById(R.id.editTextText2);
        EditText tel = findViewById(R.id.editTextPhone);
        EditText zainteresowania = findViewById(R.id.editTextText6);
        EditText mocnestrony = findViewById(R.id.editTextText9);

        RadioGroup plec = findViewById(R.id.plec);
        RadioGroup wyksztalcenie = findViewById(R.id.wyksztalcenie);

        CheckBox ang = findViewById(R.id.angielski);
        CheckBox niem = findViewById(R.id.niemiecki);
        CheckBox hisz = findViewById(R.id.hiszpanski);
        CheckBox ros = findViewById(R.id.rosyjski);
        CheckBox fr = findViewById(R.id.francuski);

        CheckBox zgoda = findViewById(R.id.checkBox4);

        TextView wynik = findViewById(R.id.textViewResult);

        if (
                imieinaz.getText().toString().isEmpty() ||
                        tel.getText().toString().isEmpty() ||
                        plec.getCheckedRadioButtonId() == -1 ||
                        wyksztalcenie.getCheckedRadioButtonId() == -1 ||
                        !zgoda.isChecked()
        ) {
            wynik.setText("Wypełnij formularz!");
            return;
        }

        StringBuilder tekst = new StringBuilder();

        tekst.append("Imię i nazwisko: ").append(imieinaz.getText()).append("\n");

        RadioButton rbPlec = findViewById(plec.getCheckedRadioButtonId());
        tekst.append("Płeć: ").append(rbPlec.getText()).append("\n");

        RadioButton rbWykszt = findViewById(wyksztalcenie.getCheckedRadioButtonId());
        tekst.append("Wykształcenie: ").append(rbWykszt.getText()).append("\n");

        tekst.append("Telefon: ").append(tel.getText()).append("\n");

        tekst.append("Języki: ");
        if (ang.isChecked()) tekst.append("Angielski ");
        if (niem.isChecked()) tekst.append("Niemiecki ");
        if (hisz.isChecked()) tekst.append("Hiszpański ");
        if (ros.isChecked()) tekst.append("Rosyjski ");
        if (fr.isChecked()) tekst.append("Francuski ");
        tekst.append("\n");

        tekst.append("Zainteresowania: ").append(zainteresowania.getText()).append("\n");
        tekst.append("Mocne strony: ").append(mocnestrony.getText()).append("\n");

        wynik.setText(tekst.toString());
    }
    private void setLayoutEnabled(boolean enabled, ViewGroup layout) {
        for (int i = 0; i < layout.getChildCount(); i++) {
            View child = layout.getChildAt(i);
            child.setEnabled(enabled);

            if (child instanceof ViewGroup) {
                setLayoutEnabled(enabled, (ViewGroup) child);
            }
        }
    }
}